console.log("hi");

var element = document.getElementById("div1");
element.classList.add("otherclass");
