//Global Variables
//This is where you will define the variables you will be using in your project.
//#TODO: Create four variables to track each possible quiz outcome
var questionCount = 0;
var newYorkScore = 0;
var cancunScore = 0;
var parisScore = 0;
var vancouverScore = 0;
var result = document.getElementById("result");

// variables for answer choice buttons for question 1
var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");
var q1a3 = document.getElementById("q1a3");
var q1a4 = document.getElementById("q1a4");

// variables for answer choice buttons for question 2
var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");
var q2a3 = document.getElementById("q2a3");
var q2a4 = document.getElementById("q2a4");

// variables for answer choice buttons for question 3
var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");
var q3a3 = document.getElementById("q3a3");
var q3a4 = document.getElementById("q3a4");

//Event Listeners for question 1
q1a1.addEventListener("click", newyork);
q1a2.addEventListener("click", cancun);
q1a3.addEventListener("click", paris);
q1a4.addEventListener("click", vancouver);

//Event Listeners for question 2
q2a1.addEventListener("click", newyork);
q2a2.addEventListener("click", cancun);
q2a3.addEventListener("click", paris);
q2a4.addEventListener("click", vancouver);

//Event Listeners for question 3
q3a1.addEventListener("click", newyork);
q3a2.addEventListener("click", cancun);
q3a3.addEventListener("click", paris);
q3a4.addEventListener("click", vancouver);

//#TODO: Define quiz functions here
function newyork() {
  newYorkScore += 1;
  questionCount += 1;
  //alert("One Point to New York!");
  if (questionCount >= 3) {
    updateResult();
  }
}
function cancun() {
  cancunScore += 1;
  questionCount += 1;
  //alert("One Point to Cancun!");
  if (questionCount >= 3) {
    updateResult();
  }
}
function paris() {
  parisScore += 1;
  questionCount += 1;
  //alert("One Point to Paris!");
  if (questionCount >= 3) {
    updateResult();
  }
}
function vancouver() {
  vancouverScore += 1;
  questionCount += 1;
  //alert("One Point to Vancouver!");
  if (questionCount >= 3) {
    updateResult();
  }
}
function updateResult() {
  if (newYorkScore >= 2) {
    result.innerHTML = "New York!";
  } else if (cancunScore >= 2) {
    result.innerHTML = "Cancun!";
  } else if (parisScore >= 2) {
    result.innerHTML = "Paris!";
  } else if (vancouverScore >= 2) {
    result.innerHTML = "Vancouver!";
  } else {
    result.innerHTML =
      "Hmm...It seems you have a different vacation in mind, try the quiz again later for another vacation spot!";
  }
}
